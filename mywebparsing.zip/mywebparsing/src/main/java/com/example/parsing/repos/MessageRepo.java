package com.example.parsing.repos;

import com.example.parsing.domain.Message;
import org.springframework.data.repository.CrudRepository;

public interface MessageRepo extends CrudRepository<Message, Long> {



}
