package com.example.parsing.controller;

import com.example.parsing.service.parsing.amtel.ParserOpenAmtel;
import com.example.parsing.service.uploadsFiles.FilesOnDisk;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Map;

@Controller
public class MainController {


    

    @Value("${upload.path}")
    private String uploadPath;

    @GetMapping("/main")
    public String mainPage() {

        return "main";
    }

    @GetMapping("/parsing")
    public String parsingPage(
            Map<String, Object> model
    ) {

        FilesOnDisk filesOnDisk = new FilesOnDisk();

        model.put("arrUploadsFiles", filesOnDisk.outFilesOnDisk(uploadPath));

        return "parsing";
    }


    @PostMapping("/parsing")
    public String add(
            Map<String, Object> model,
            @RequestParam("file") MultipartFile file
    ) throws IOException {

        if (file != null && !file.getOriginalFilename().isEmpty()) {
            File uploadDir = new File(uploadPath);

            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }

/*            String uuidFile = UUID.randomUUID().toString();
            System.out.println(uuidFile);
            String resultFilename = uuidFile + "." + file.getOriginalFilename();*/
            String resultFilename = file.getOriginalFilename();
            System.out.println(resultFilename);

            file.transferTo(new File(uploadPath + "/" + resultFilename));


        }
        FilesOnDisk filesOnDisk = new FilesOnDisk();

        model.put("arrUploadsFiles", filesOnDisk.outFilesOnDisk(uploadPath));

        return "parsing";
    }

    @PostMapping("/startparsing")
    public String startParsing(
            @RequestParam(name="arrUploadsFiles") String arrUploadsFiles,
            @RequestParam(name="siteSelect", required=false, defaultValue="None") String siteSelect,
            Map<String, Object> model
    ) throws InterruptedException {
        FilesOnDisk filesOnDisk = new FilesOnDisk();
        model.put("arrUploadsFiles", filesOnDisk.outFilesOnDisk(uploadPath));


        System.out.println("1111111");
        System.out.println(arrUploadsFiles);
        System.out.println(siteSelect);


        if (siteSelect.equals("Amtel")) {

            try {
                ParserOpenAmtel.parsing(uploadPath + "/" + arrUploadsFiles, "gorelko90@gmail.com");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        } else if (siteSelect.equals("Emex")) {


        } else if (siteSelect.equals("None")) {
            return "parsing";
        }

        return "parsing";
    }




}
