package com.example.parsing.repos;

import com.example.parsing.domain.ParsingResult;
import org.springframework.data.repository.CrudRepository;

public interface ParsingRepo extends CrudRepository<ParsingResult, Long> {



}